// This service encapsulates the logic for using the Google Picker API.
// It allows users to select files from their Google Drive.

declare global {
    interface Window {
        gapi: any;
        google: any;
    }
}

let gapiLoaded = false;
let pickerApiLoaded = false;
let oauthToken: string | null = null;

export const isGoogleDriveConfigured = (): boolean => {
    return !!process.env.GOOGLE_CLIENT_ID && !!process.env.API_KEY;
};

export const loadGapiScript = (): Promise<void> => {
    return new Promise((resolve, reject) => {
        if (gapiLoaded) {
            resolve();
            return;
        }
        const script = document.createElement('script');
        script.src = 'https://apis.google.com/js/api.js';
        script.onload = () => {
            gapiLoaded = true;
            window.gapi.load('auth2:picker', () => {
                pickerApiLoaded = true;
                resolve();
            });
        };
        script.onerror = () => reject(new Error('Failed to load Google API script.'));
        document.body.appendChild(script);
    });
};

const getOauthToken = (): Promise<string> => {
    return new Promise((resolve, reject) => {
        if (!process.env.GOOGLE_CLIENT_ID) {
            return reject(new Error("El ID de cliente de Google (GOOGLE_CLIENT_ID) no está configurado."));
        }
        
        window.gapi.auth2.init({
            clientId: process.env.GOOGLE_CLIENT_ID,
            scope: 'https://www.googleapis.com/auth/drive.readonly',
        }).then(() => {
            const authInstance = window.gapi.auth2.getAuthInstance();
            if (authInstance.isSignedIn.get()) {
                const googleUser = authInstance.currentUser.get();
                const token = googleUser.getAuthResponse().access_token;
                oauthToken = token;
                resolve(token);
            } else {
                authInstance.signIn().then((googleUser: any) => {
                    const token = googleUser.getAuthResponse().access_token;
                    oauthToken = token;
                    resolve(token);
                }).catch((err: any) => {
                     reject(new Error(`Error de autenticación con Google: ${err.error || 'El usuario cerró la ventana.'}`));
                });
            }
        }).catch((err: any) => reject(new Error(`Error al inicializar la autenticación de Google: ${err.details}`)));
    });
};

export const showPicker = (): Promise<File | null> => {
    return new Promise(async (resolve, reject) => {
        if (!pickerApiLoaded) {
            return reject(new Error("La API de Google Picker no está lista."));
        }
        if (!process.env.API_KEY) {
            return reject(new Error("La API key de Google no está configurada."));
        }
        
        try {
            const token = oauthToken || await getOauthToken();

            const pickerCallback = async (data: any) => {
                if (data.action === window.google.picker.Action.PICKED) {
                    const doc = data.docs[0];
                    const fileId = doc.id;
                    const fileName = doc.name;
                    const mimeType = doc.mimeType;

                    const response = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    });

                    if (!response.ok) {
                        return reject(new Error(`Error al descargar el archivo de Drive: ${response.statusText}`));
                    }
                    
                    const blob = await response.blob();
                    const file = new File([blob], fileName, { type: mimeType });
                    resolve(file);

                } else if (data.action === window.google.picker.Action.CANCEL) {
                    reject(new Error("The user closed the picker."));
                }
            };
            
            const view = new window.google.picker.View(window.google.picker.ViewId.DOCS);
            view.setMimeTypes("image/png,image/jpeg,image/jpg,audio/mpeg,audio/wav,video/mp4,application/pdf,text/plain");

            const picker = new window.google.picker.PickerBuilder()
                .enableFeature(window.google.picker.Feature.NAV_HIDDEN)
                .setAppId(process.env.GOOGLE_CLIENT_ID?.split('-')[0] || '')
                .setOAuthToken(token)
                .addView(view)
                .addView(new window.google.picker.DocsUploadView())
                .setDeveloperKey(process.env.API_KEY)
                .setCallback(pickerCallback)
                .build();
            
            picker.setVisible(true);

        } catch (error) {
            reject(error);
        }
    });
};

const getFileMetadata = async (fileId: string, token: string): Promise<{ name: string, mimeType: string }> => {
    const response = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?fields=name,mimeType`, {
        headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!response.ok) {
        throw new Error(`No se pudo obtener la metadata del archivo de Drive: ${response.statusText}`);
    }
    return response.json();
}

const downloadFileContent = async (fileId: string, token: string): Promise<Blob> => {
    const response = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
        headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!response.ok) {
        throw new Error(`Error al descargar el archivo de Drive: ${response.statusText}`);
    }
    return response.blob();
}

export const downloadFileFromId = async (fileId: string): Promise<File> => {
    try {
        const token = await getOauthToken();
        const metadata = await getFileMetadata(fileId, token);
        const blob = await downloadFileContent(fileId, token);
        return new File([blob], metadata.name, { type: metadata.mimeType });
    } catch (error) {
        console.error("Error downloading file from Drive:", error);
        if (error instanceof Error) {
            // Re-throw specific errors to be handled by the UI
            throw new Error(`No se pudo descargar el archivo: ${error.message}`);
        }
        throw new Error("Ocurrió un error desconocido al descargar el archivo de Drive.");
    }
};