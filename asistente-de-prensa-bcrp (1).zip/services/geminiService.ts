import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { AnalysisResult, FactCheckComparisonResult } from '../types';

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
        if (typeof reader.result === 'string') {
            resolve(reader.result.split(',')[1]);
        } else {
            reject(new Error("Failed to read file as base64 string."));
        }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

const buildPrompt = (inputType: 'text' | 'image' | 'audio' | 'video'): string => {
    let analysisTarget = '';
    switch(inputType) {
        case 'text':
            analysisTarget = `Texto para analizar:\n"""\n{TEXT_PLACEHOLDER}\n"""`;
            break;
        case 'image':
            analysisTarget = `El texto para analizar está contenido en la imagen adjunta. Por favor, realiza un OCR sobre la imagen primero y luego procede con el análisis.`;
            break;
        case 'audio':
            analysisTarget = `El texto para analizar está contenido en el archivo de audio adjunto. Por favor, transcribe el audio primero y luego procede con el análisis del texto transcrito.`;
            break;
        case 'video':
            analysisTarget = `El texto para analizar está contenido en el archivo de video adjunto. Por favor, transcribe el audio del video primero y luego procede con el análisis del texto transcrito.`;
            break;
    }
    
    return `
Eres el Asistente de Prensa del Banco Central de Reserva del Perú (BCRP). Tu única función es recibir un texto (o un archivo multimedia con texto/audio) y analizarlo según reglas estrictas para producir una respuesta estructurada en formato JSON. Eres objetivo, preciso y profesional.

${analysisTarget}

Reglas de Análisis:
1. **Identificación de Menciones:** Busca menciones literales o implícitas de las siguientes entidades, personas y sus variantes:
    - **Institución:** Banco Central de Reserva del Perú, Banco Central, BCRP, BCR, ente monetario, autoridad monetaria, institución monetaria, banco emisor, ente emisor, autoridad emisora, ente rector de la política monetaria, banco central peruano.
    - **Presidente:** Julio Velarde, Julio Emilio Velarde Flores, Presidente del Directorio del BCRP, Presidente del Directorio del Banco Central de Reserva del Perú, Presidente del Banco Central, Presidente del BCR, Presidente del ente monetario, Presidente de la autoridad monetaria, Presidente del banco emisor.
    - **Directorio:** Carlos Augusto Oliva Neyra, Carlos Oliva, Germán Alejandro Alarco Tosoni, Germán Alarco, Roxana María Irma Barrantes Cáceres, Roxana Barrantes, Inés Marylin Choy Chong, Inés Choy, Diego Macera Poli, Diego Macera, José Ignacio Távara Martín, José Távara.
    - **Funcionarios:** Paul Castillo Bardález, Paul Castillo, Adrián Alejandro Armas Rivas, Adrián Armas.

2. **Extracción de Oraciones:** Si encuentras alguna mención, extrae la oración completa y textual donde aparece. La oración debe ser exacta a como aparece en el texto fuente.

3. **Elaboración del Resumen:**
    - **Estructura:** Comienza con una introducción breve según el tipo de texto (entrevista, columna de opinión, cita, etc.), seguido del dato clave, un contexto breve, y la fuente en cursivas y paréntesis al final (ej. * (El Comercio)*). Si la fuente no está en el texto, usa '(fuente)'.
    - **Tono:** Objetivo, conciso, impersonal, profesional.
    - **Longitud:** Estrictamente entre 45 y 55 palabras.
    - **Formato Numérico:** Usa un espacio como separador de miles y una coma como separador decimal (ej. "3,1 %", "USD 26 235 millones").
    - **Contenido:** Basa el resumen estrictamente en el texto proporcionado, sin añadir ni inferir información.

4. **Proporcionar Transcripción Completa:** Si la entrada es un archivo de audio o video, primero transcríbelo por completo. El texto completo de la transcripción DEBE ser incluido en el campo 'transcription' de la respuesta JSON. Si la entrada es solo texto o una imagen, el campo 'transcription' debe ser una cadena vacía ("").

Genera la respuesta estrictamente en el formato JSON especificado en el esquema. No incluyas explicaciones adicionales, solo el objeto JSON.
`;
}

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        transcription: {
            type: Type.STRING,
            description: "La transcripción completa y literal del audio o video. Si la entrada es solo texto o imagen, este campo debe ser una cadena vacía."
        },
        hasMentions: {
            type: Type.BOOLEAN,
            description: "Indica con 'true' si se encontraron menciones al BCRP o sus autoridades, y 'false' en caso contrario."
        },
        foundSentences: {
            type: Type.ARRAY,
            description: "Una lista de strings, donde cada string es la oración completa y textual que contiene una mención. Si no hay menciones, debe ser un array vacío.",
            items: { type: Type.STRING }
        },
        summary: {
            type: Type.STRING,
            description: "Un resumen del artículo de 45-55 palabras siguiendo todas las reglas de formato, tono y estructura especificadas."
        }
    },
    required: ["transcription", "hasMentions", "foundSentences", "summary"]
};

export const analyzeContent = async (text: string, file: File | null): Promise<AnalysisResult> => {
    if (!process.env.API_KEY) {
        throw new Error("API key no encontrada. Asegúrate de que la variable de entorno API_KEY esté configurada.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const parts: ({inlineData: {data:string, mimeType: string}} | {text: string})[] = [];

    if (file) {
        const filePart = await fileToGenerativePart(file);
        parts.push(filePart);
        const mimeTypePrefix = file.type.split('/')[0];
        let inputType: 'image' | 'audio' | 'video';

        if (mimeTypePrefix === 'image') {
            inputType = 'image';
        } else if (mimeTypePrefix === 'audio') {
            inputType = 'audio';
        } else if (mimeTypePrefix === 'video') {
            inputType = 'video';
        } else {
             throw new Error(`Tipo de archivo no soportado: ${file.type}`);
        }
        parts.push({ text: buildPrompt(inputType) });

    } else if (text) {
        parts.push({ text: buildPrompt('text').replace('{TEXT_PLACEHOLDER}', text) });
    } else {
        throw new Error("Se debe proporcionar texto o un archivo.");
    }

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts },
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
                temperature: 0.2,
            }
        });
        
        const jsonString = response.text.trim();
        const cleanedJsonString = jsonString.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        
        return JSON.parse(cleanedJsonString);

    } catch (error) {
        console.error("Error al analizar el contenido:", error);
        throw new Error("No se pudo obtener una respuesta válida del modelo. Por favor, intenta de nuevo.");
    }
};

const buildFactCheckPrompt = (articleIsText: boolean, officialText: string): string => {
    const articleInputInstruction = articleIsText
        ? `1. El artículo periodístico a analizar es el siguiente:\n"""\n{ARTICLE_PLACEHOLDER}\n"""`
        : `1. El artículo periodístico a analizar está en la imagen adjunta. Primero, realiza un OCR para extraer el texto completo.`;
    
    return `
**Rol del asistente:**
Eres un verificador de hechos especializado en comparar artículos periodísticos sobre el **Banco Central de Reserva del Perú (BCRP)** con documentos oficiales del BCRP. Tu tarea es identificar coincidencias, contradicciones y omisiones **línea por línea**, usando un sistema tipo semáforo para clasificar cada afirmación y devolver el resultado en un formato JSON estructurado.

**Instrucciones:**

${articleInputInstruction}

2.  El texto oficial del BCRP para usar como fuente de verdad es el siguiente:
    """
    ${officialText}
    """

3.  Divide el texto del artículo periodístico (extraído del texto o de la imagen) en **líneas o párrafos numerados lógicamente**.

4.  Para cada línea o párrafo numerado:
    *   Determina si contiene una afirmación factual verificable.
    *   Compara la afirmación con el **texto oficial del BCRP**, usando coincidencia textual y numérica flexible (permite formatos de números y fechas distintos).
    *   Clasifica la afirmación usando una de las siguientes categorías estrictas: "VERDADERO", "FALSO", "PARCIAL", "NO VERIFICABLE", "SIN AFIRMACIÓN".
    *   Justifica cada clasificación citando textualmente la parte relevante del texto oficial o explicando por qué no es verificable.

5.  **Genera un resumen final:**
    *   Calcula el porcentaje de líneas para las clasificaciones "VERDADERO", "FALSO" y "PARCIAL" sobre el total de líneas analizadas. Redondea al entero más cercano.
    *   Basado en los porcentajes, proporciona una evaluación general de la fidelidad del artículo como "Alta", "Media" o "Baja".

6.  **Formato de Salida:**
    *   Devuelve tu análisis completo estrictamente en el formato JSON definido en el esquema. No incluyas explicaciones fuera del objeto JSON.
`;
}

const factCheckSchema = {
    type: Type.OBJECT,
    properties: {
        analysis: {
            type: Type.ARRAY,
            description: "Análisis línea por línea del artículo.",
            items: {
                type: Type.OBJECT,
                properties: {
                    line: { type: Type.INTEGER, description: "Número de la línea o párrafo analizado." },
                    originalText: { type: Type.STRING, description: "El texto original de la línea o párrafo." },
                    classification: {
                        type: Type.STRING,
                        enum: ['VERDADERO', 'FALSO', 'PARCIAL', 'NO VERIFICABLE', 'SIN AFIRMACIÓN'],
                        description: "Clasificación de la afirmación."
                    },
                    justification: { type: Type.STRING, description: "Justificación basada en el texto oficial." }
                },
                required: ["line", "originalText", "classification", "justification"]
            }
        },
        summary: {
            type: Type.OBJECT,
            description: "Resumen cuantitativo del análisis.",
            properties: {
                percentVerdadero: { type: Type.INTEGER, description: "Porcentaje de líneas clasificadas como VERDADERO." },
                percentFalso: { type: Type.INTEGER, description: "Porcentaje de líneas clasificadas como FALSO." },
                percentParcial: { type: Type.INTEGER, description: "Porcentaje de líneas clasificadas como PARCIAL." },
                overallFidelity: {
                    type: Type.STRING,
                    enum: ['Alta', 'Media', 'Baja'],
                    description: "Evaluación general de la fidelidad del artículo."
                }
            },
            required: ["percentVerdadero", "percentFalso", "percentParcial", "overallFidelity"]
        }
    },
    required: ["analysis", "summary"]
};

export const factCheckComparison = async (article: { text?: string; file?: File | null }, officialText: string): Promise<FactCheckComparisonResult> => {
    if (!process.env.API_KEY) {
        throw new Error("API key no encontrada. Asegúrate de que la variable de entorno API_KEY esté configurada.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const parts: ({inlineData: {data:string, mimeType: string}} | {text: string})[] = [];

    if (article.file) {
        const filePart = await fileToGenerativePart(article.file);
        parts.push(filePart);
        parts.push({ text: buildFactCheckPrompt(false, officialText) });
    } else if (article.text) {
        const prompt = buildFactCheckPrompt(true, officialText).replace('{ARTICLE_PLACEHOLDER}', article.text);
        parts.push({ text: prompt });
    } else {
        throw new Error("Se debe proporcionar un artículo (texto o archivo).");
    }

    if (!officialText.trim()) {
        throw new Error("Se debe proporcionar el texto oficial del BCRP.");
    }

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts },
            config: {
                responseMimeType: "application/json",
                responseSchema: factCheckSchema,
                temperature: 0.1,
            }
        });

        const jsonString = response.text.trim();
        const cleanedJsonString = jsonString.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        
        return JSON.parse(cleanedJsonString);
    } catch (error) {
        console.error("Error al verificar el contenido:", error);
        throw new Error("No se pudo obtener una respuesta válida del verificador. Por favor, intenta de nuevo.");
    }
};
