import React, { useState } from 'react';
import { Header } from './components/Header';
import { Navigation, Tool } from './components/Navigation';
import { BcrpAnalysisPage } from './pages/BcrpAnalysisPage';
import { FactCheckPage } from './pages/FactCheckPage';

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<Tool>('bcrp');

  const renderActiveTool = () => {
    switch(activeTool) {
      case 'bcrp':
        return <BcrpAnalysisPage />;
      case 'fact-check':
        return <FactCheckPage />;
      default:
        return <BcrpAnalysisPage />;
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 font-sans">
      <Header />
      <main className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <aside className="md:col-span-1">
            <Navigation activeTool={activeTool} setActiveTool={setActiveTool} />
          </aside>
          <div className="md:col-span-3">
            {renderActiveTool()}
          </div>
        </div>
        <footer className="text-center text-sm text-gray-500 mt-12 pb-4">
          <p>&copy; {new Date().getFullYear()} Panel de Herramientas de Prensa BCRP.</p>
        </footer>
      </main>
    </div>
  );
};

export default App;