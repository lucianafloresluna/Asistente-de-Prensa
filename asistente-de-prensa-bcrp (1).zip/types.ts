export interface AnalysisResult {
  hasMentions: boolean;
  foundSentences: string[];
  summary: string;
  transcription?: string;
}

export interface LineAnalysis {
  line: number;
  originalText: string;
  classification: 'VERDADERO' | 'FALSO' | 'PARCIAL' | 'NO VERIFICABLE' | 'SIN AFIRMACIÓN';
  justification: string;
}

export interface FactCheckComparisonResult {
  analysis: LineAnalysis[];
  summary: {
    percentVerdadero: number;
    percentFalso: number;
    percentParcial: number;
    overallFidelity: 'Alta' | 'Media' | 'Baja';
  };
}
