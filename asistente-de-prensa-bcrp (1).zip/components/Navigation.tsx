import React from 'react';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

export type Tool = 'bcrp' | 'fact-check';

interface NavigationProps {
    activeTool: Tool;
    setActiveTool: (tool: Tool) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTool, setActiveTool }) => {
    
    const navItems = [
        { id: 'bcrp', label: 'Análisis BCRP', icon: <DocumentTextIcon className="h-5 w-5 mr-3" /> },
        { id: 'fact-check', label: 'Verificador de Datos', icon: <CheckCircleIcon className="h-5 w-5 mr-3" /> }
    ];

    const baseClasses = "flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-150";
    const activeClasses = "bg-blue-600 text-white shadow";
    const inactiveClasses = "text-gray-600 hover:bg-gray-200 hover:text-gray-900";

    return (
        <nav className="bg-white p-4 rounded-xl shadow-lg space-y-2">
             <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider px-2 pb-2">Herramientas</h2>
            {navItems.map(item => (
                <button
                    key={item.id}
                    onClick={() => setActiveTool(item.id as Tool)}
                    className={`${baseClasses} ${activeTool === item.id ? activeClasses : inactiveClasses}`}
                >
                    {item.icon}
                    <span>{item.label}</span>
                </button>
            ))}
        </nav>
    );
};