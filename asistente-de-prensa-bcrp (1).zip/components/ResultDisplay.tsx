import React, { useState } from 'react';
import { AnalysisResult } from '../types';
import { Spinner } from './Spinner';
import { ClipboardIcon } from './icons/ClipboardIcon';

interface ResultDisplayProps {
  result: AnalysisResult | null;
  isLoading: boolean;
  error: string | null;
}

const ResultSection: React.FC<{title: string; children: React.ReactNode}> = ({ title, children }) => (
    <div>
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">{title}</h3>
        <div className="text-gray-800 bg-slate-50 p-4 rounded-lg border border-gray-200">
            {children}
        </div>
    </div>
);

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, isLoading, error }) => {
    const [isCopied, setIsCopied] = useState(false);

    const handleCopy = (textToCopy: string) => {
        navigator.clipboard.writeText(textToCopy).then(() => {
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        });
    };

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-center">
                    <Spinner />
                    <p className="mt-4 text-gray-600 font-medium">Procesando solicitud...</p>
                    <p className="mt-1 text-sm text-gray-500">El análisis de audio y video puede tomar más tiempo.</p>
                </div>
            );
        }
        if (error) {
            return (
                <div className="text-red-700 bg-red-50 p-4 rounded-lg border border-red-200">
                    <h4 className="font-bold">Error en el Análisis</h4>
                    <p>{error}</p>
                </div>
            );
        }
        if (!result) {
            return <div className="flex items-center justify-center h-full text-center text-gray-500">Los resultados del análisis aparecerán aquí.</div>;
        }

        return (
            <div className="space-y-6 animate-fade-in">
                {result.transcription && (
                    <ResultSection title="Transcripción Completa">
                        <div className="relative">
                             <button
                                onClick={() => handleCopy(result.transcription ?? '')}
                                className="absolute top-2 right-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold py-1 px-2 rounded-md text-xs inline-flex items-center transition-colors"
                                title="Copiar al portapapeles"
                            >
                                <ClipboardIcon className="h-4 w-4 mr-1" />
                                {isCopied ? 'Copiado' : 'Copiar'}
                            </button>
                            <pre className="whitespace-pre-wrap leading-relaxed bg-slate-100 p-3 rounded-md max-h-48 overflow-y-auto font-sans text-sm border">
                                {result.transcription}
                            </pre>
                        </div>
                    </ResultSection>
                )}

                <ResultSection title="1) ¿Hay menciones al BCRP o a sus autoridades?">
                    <p className={`font-bold text-lg ${result.hasMentions ? 'text-green-600' : 'text-orange-600'}`}>
                        {result.hasMentions ? 'Sí' : 'No'}
                    </p>
                </ResultSection>

                <ResultSection title="2) Menciones encontradas (oración completa entre comillas)">
                    {result.foundSentences.length > 0 ? (
                        <ul className="space-y-3">
                            {result.foundSentences.map((sentence, index) => (
                                <li key={index} className="flex items-start">
                                    <span className="text-blue-500 mr-2 mt-1">&#8226;</span>
                                    <p className="italic">"{sentence}"</p>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="italic text-gray-600">Ninguna</p>
                    )}
                </ResultSection>

                <ResultSection title="3) Resumen del artículo">
                    <p className="whitespace-pre-wrap leading-relaxed">{result.summary}</p>
                </ResultSection>
            </div>
        );
    }
    
    return (
        <div className="bg-white p-6 rounded-xl shadow-lg h-full">
          <h2 className="text-xl font-semibold text-gray-800 mb-4 border-b pb-3">Resultados del Análisis</h2>
          <div className="min-h-[300px] flex flex-col justify-center">
            {renderContent()}
          </div>
        </div>
    );
};