import React, { useState, useEffect } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import { AudioIcon } from './icons/AudioIcon';
import { VideoIcon } from './icons/VideoIcon';
import { GoogleDriveIcon } from './icons/GoogleDriveIcon';


interface InputAreaProps {
  text: string;
  setText: (text: string) => void;
  file: File | null;
  setFile: (file: File | null) => void;
  onSubmit: () => void;
  isLoading: boolean;
  onSelectFromDrive: () => void;
  isDriveReady: boolean;
  onImportFromUrl: (url: string) => void;
  isImporting: boolean;
}

export const InputArea: React.FC<InputAreaProps> = ({ text, setText, file, setFile, onSubmit, isLoading, onSelectFromDrive, isDriveReady, onImportFromUrl, isImporting }) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [detectedUrl, setDetectedUrl] = useState<string | null>(null);
  
  const DRIVE_URL_REGEX = /https:\/\/drive\.google\.com\/(?:file\/d\/|open\?id=)([a-zA-Z0-9_-]{25,})/;

  useEffect(() => {
    if (!isDriveReady) {
      setDetectedUrl(null);
      return;
    }
    const match = text.match(DRIVE_URL_REGEX);
    if (match && !file) {
      setDetectedUrl(text.trim());
    } else {
      setDetectedUrl(null);
    }
  }, [text, file, isDriveReady]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setText('');
    }
  };

  const handleRemoveFile = () => {
    setFile(null);
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setText(e.target.value);
      if (e.target.value && file) {
        handleRemoveFile();
      }
  }

  const renderFilePreview = () => {
    if (!file) return null;

    const fileType = file.type.split('/')[0];

    switch (fileType) {
        case 'image':
            return <img src={URL.createObjectURL(file)} alt="Vista previa" className="max-h-40 object-contain rounded-md mb-2" />;
        case 'audio':
            return <div className="flex flex-col items-center justify-center text-slate-600"><AudioIcon className="w-16 h-16" /><span className="mt-2 text-sm font-medium">Archivo de Audio</span></div>;
        case 'video':
            return <div className="flex flex-col items-center justify-center text-slate-600"><VideoIcon className="w-16 h-16" /><span className="mt-2 text-sm font-medium">Archivo de Video</span></div>;
        default:
            return <div className="flex flex-col items-center justify-center text-slate-600"><UploadIcon className="w-16 h-16" /><span className="mt-2 text-sm font-medium">Archivo</span></div>;
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg space-y-4 h-full">
      <h2 className="text-xl font-semibold text-gray-800 border-b pb-3">Contenido a Analizar</h2>
      <div className="relative">
        <textarea
          className="w-full h-64 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow duration-200 resize-none disabled:bg-gray-100"
          placeholder="Pega aquí el texto del artículo, un enlace de Google Drive, o sube un archivo..."
          value={text}
          onChange={handleTextChange}
          disabled={isLoading || !!file || isImporting}
        />
        {file && (
          <div className="absolute inset-0 bg-white p-4 rounded-lg flex flex-col items-center justify-center border-2 border-dashed border-blue-500">
            {renderFilePreview()}
            <p className="text-sm font-medium text-gray-700 truncate max-w-full mt-2">{file.name}</p>
            <button 
              onClick={handleRemoveFile}
              disabled={isLoading}
              className="mt-2 text-sm text-red-600 hover:text-red-800 disabled:opacity-50 font-medium"
            >
              Quitar archivo
            </button>
          </div>
        )}
      </div>

      {detectedUrl && isDriveReady && (
        <div className="animate-fade-in text-center border-t pt-4">
          <button
            onClick={() => onImportFromUrl(detectedUrl)}
            disabled={isImporting || isLoading}
            className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isImporting ? (
                <>
                  <Spinner />
                  <span className="ml-2">Cargando desde Drive...</span>
                </>
            ) : (
                <>
                    <GoogleDriveIcon className="h-5 w-5 mr-2" />
                    Cargar desde este enlace de Drive
                </>
            )}
          </button>
        </div>
      )}
      
      <div className="border-t pt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <input 
              type="file" 
              accept="image/*,audio/*,video/*" 
              ref={fileInputRef} 
              onChange={handleFileChange}
              className="hidden"
              id="file-upload"
              disabled={isLoading || isImporting}
            />
            <label 
              htmlFor="file-upload" 
              className={`inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${(isLoading || isImporting) ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
            >
              <UploadIcon className="h-5 w-5 mr-2" />
              Subir Archivo
            </label>
            <button
              onClick={onSelectFromDrive}
              disabled={isLoading || !isDriveReady || isImporting}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              title={!isDriveReady ? 'La integración con Google Drive no está configurada.' : 'Seleccionar archivo desde Google Drive'}
            >
              <GoogleDriveIcon className="h-5 w-5 mr-2" />
              Seleccionar de Drive
            </button>
          </div>
          
          <button
            onClick={onSubmit}
            disabled={isLoading || (!text && !file) || isImporting}
            className="inline-flex items-center justify-center px-6 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? (
              <>
                <Spinner />
                <span className="ml-2">Analizando...</span>
              </>
            ) : 'Analizar'}
          </button>
        </div>
        {!isDriveReady && (
            <div className="text-xs text-gray-500 text-center pt-3">
                <p>La integración con Google Drive no está disponible porque las credenciales no están configuradas.</p>
            </div>
        )}
      </div>
    </div>
  );
};

// Add a minimal spinner directly here to avoid another file import within this component
const Spinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);