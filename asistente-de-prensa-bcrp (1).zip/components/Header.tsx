
import React from 'react';

export const Header = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex items-center space-x-4">
        <img src="https://www.bcrp.gob.pe/docs/Publicaciones/Revista-Moneda/moneda-181/moneda-181-01.png" alt="Logo BCRP" className="h-12 w-12 object-contain" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Panel de Herramientas de Prensa</h1>
          <p className="text-sm text-gray-500">BCRP</p>
        </div>
      </div>
    </header>
  );
};