import React from 'react';

export const GoogleDriveIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 48 48" width="48px" height="48px">
    <path fill="#4CAF50" d="M32.022,14.004l-6.958,12.039l-6.958-12.039H11.022l11,19.012l11-19.012H32.022z"/>
    <path fill="#1E88E5" d="M11.022,14.004l6.958,12.039l-3.479,6.012l-11-19.012h11.022L11.022,14.004z"/>
    <path fill="#FFC107" d="M36.978,14.004h-7.5l-3.479,6.012l6.958,12.039l11-19.012H36.978z"/>
  </svg>
);