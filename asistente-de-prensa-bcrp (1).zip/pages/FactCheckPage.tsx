import React, { useState, useRef } from 'react';
import { factCheckComparison, } from '../services/geminiService';
import { FactCheckComparisonResult, LineAnalysis } from '../types';
import { Spinner } from '../components/Spinner';
import { UploadIcon } from '../components/icons/UploadIcon';

const classificationStyles: Record<LineAnalysis['classification'], { emoji: string; color: string; bg: string; border: string; }> = {
    'VERDADERO': { emoji: '🟢', color: 'text-green-800', bg: 'bg-green-50', border: 'border-green-200' },
    'FALSO': { emoji: '🔴', color: 'text-red-800', bg: 'bg-red-50', border: 'border-red-200' },
    'PARCIAL': { emoji: '🟡', color: 'text-yellow-800', bg: 'bg-yellow-50', border: 'border-yellow-200' },
    'NO VERIFICABLE': { emoji: '⚪', color: 'text-slate-700', bg: 'bg-slate-100', border: 'border-slate-200' },
    'SIN AFIRMACIÓN': { emoji: '⚫', color: 'text-gray-700', bg: 'bg-gray-200', border: 'border-gray-300' },
};

export const FactCheckPage: React.FC = () => {
    const [articleText, setArticleText] = useState<string>('');
    const [articleFile, setArticleFile] = useState<File | null>(null);
    const [officialText, setOfficialText] = useState<string>('');

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [result, setResult] = useState<FactCheckComparisonResult | null>(null);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setArticleFile(e.target.files[0]);
            setArticleText(''); // Clear text input when file is selected
        }
    };

    const handleRemoveFile = () => {
        setArticleFile(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };
    
    const handleSubmit = async () => {
        if ((!articleText.trim() && !articleFile) || !officialText.trim()) {
            setError("Por favor, proporciona tanto el artículo como el texto oficial.");
            return;
        };
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const factCheckResult = await factCheckComparison({ text: articleText, file: articleFile }, officialText);
            setResult(factCheckResult);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError('Ocurrió un error inesperado al verificar.');
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="space-y-8 animate-fade-in">
            <div className="bg-white p-6 rounded-xl shadow-lg">
                <h2 className="text-xl font-semibold text-gray-800">Verificador de Datos por Comparación</h2>
                <p className="text-sm text-gray-500 mt-1">Compara un artículo periodístico (texto o imagen) con un documento oficial del BCRP para verificar su fidelidad.</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                {/* Article Input */}
                <div className="bg-white p-6 rounded-xl shadow-lg space-y-4">
                    <h3 className="text-lg font-semibold text-gray-800">1. Artículo Periodístico a Verificar</h3>
                    <div className="relative">
                        <textarea
                            className="w-full h-48 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow duration-200 resize-y disabled:bg-gray-100"
                            placeholder="Pega aquí el texto del artículo..."
                            value={articleText}
                            onChange={(e) => { setArticleText(e.target.value); if(articleFile) handleRemoveFile(); }}
                            disabled={isLoading || !!articleFile}
                        />
                         {articleFile && (
                            <div className="absolute inset-0 bg-white p-4 rounded-lg flex flex-col items-center justify-center border-2 border-dashed border-blue-500">
                                <img src={URL.createObjectURL(articleFile)} alt="Vista previa" className="max-h-24 object-contain rounded-md mb-2" />
                                <p className="text-xs font-medium text-gray-700 truncate max-w-full">{articleFile.name}</p>
                                <button onClick={handleRemoveFile} disabled={isLoading} className="mt-1 text-xs text-red-600 hover:text-red-800">Quitar</button>
                            </div>
                        )}
                    </div>
                    <div className="text-center text-sm text-gray-500">o</div>
                    <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" id="article-file-upload"/>
                    <label htmlFor="article-file-upload" className={`w-full inline-flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 ${isLoading ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}>
                        <UploadIcon className="h-5 w-5 mr-2" /> Subir como Imagen (OCR)
                    </label>
                </div>
                {/* Official Text Input */}
                <div className="bg-white p-6 rounded-xl shadow-lg space-y-4">
                     <h3 className="text-lg font-semibold text-gray-800">2. Texto Oficial del BCRP</h3>
                     <textarea
                        className="w-full h-64 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow duration-200 resize-y disabled:bg-gray-100"
                        placeholder="Pega aquí el texto de la fuente oficial (informe, discurso, nota de prensa, etc.)."
                        value={officialText}
                        onChange={(e) => setOfficialText(e.target.value)}
                        disabled={isLoading}
                    />
                </div>
            </div>

            <div className="text-center">
                <button onClick={handleSubmit} disabled={isLoading || (!articleText.trim() && !articleFile) || !officialText.trim()} className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors">
                    {isLoading ? ( <><svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> <span>Comparando...</span></> ) : 'Realizar Verificación'}
                </button>
            </div>

            {isLoading && <div className="text-center py-8"><Spinner /><p className="mt-2 text-sm text-gray-500">Analizando y comparando documentos...</p></div>}
            {error && <div className="text-red-700 bg-red-50 p-4 rounded-lg border border-red-200"><h4 className="font-bold">Error en la Verificación</h4><p>{error}</p></div>}

            {result && (
                <div className="bg-white p-6 rounded-xl shadow-lg space-y-6 animate-fade-in">
                    <h2 className="text-xl font-semibold text-gray-800 border-b pb-3">Informe de Verificación de Hechos – BCRP</h2>
                    <div className="space-y-4">
                        {result.analysis.map((item) => {
                            const style = classificationStyles[item.classification];
                            return (
                                <div key={item.line} className={`p-4 rounded-lg border ${style.bg} ${style.border}`}>
                                    <p className="font-mono text-xs text-gray-500">LÍNEA {item.line}</p>
                                    <p className="italic text-gray-800 my-2">"{item.originalText}"</p>
                                    <div className="flex items-center space-x-2">
                                        <span className="font-bold text-sm">{style.emoji} {item.classification}</span>
                                    </div>
                                    <div className="mt-2 pt-2 border-t border-dashed">
                                        <p className={`text-sm ${style.color}`}><span className="font-semibold">Justificación:</span> {item.justification}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    <div className="pt-6 border-t">
                        <h3 className="text-lg font-semibold text-gray-800 mb-3">Resumen Final</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                             <div className="p-3 bg-green-50 rounded-lg border border-green-200"><p className="font-bold text-xl text-green-700">{result.summary.percentVerdadero}%</p><p className="text-sm text-green-800">Verdadero</p></div>
                             <div className="p-3 bg-red-50 rounded-lg border border-red-200"><p className="font-bold text-xl text-red-700">{result.summary.percentFalso}%</p><p className="text-sm text-red-800">Falso</p></div>
                             <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200"><p className="font-bold text-xl text-yellow-700">{result.summary.percentParcial}%</p><p className="text-sm text-yellow-800">Parcial</p></div>
                             <div className={`p-3 rounded-lg border ${result.summary.overallFidelity === 'Alta' ? 'bg-blue-50 border-blue-200' : result.summary.overallFidelity === 'Media' ? 'bg-orange-50 border-orange-200' : 'bg-gray-200 border-gray-300'}`}><p className={`font-bold text-xl ${result.summary.overallFidelity === 'Alta' ? 'text-blue-700' : result.summary.overallFidelity === 'Media' ? 'text-orange-700' : 'text-gray-700'}`}>{result.summary.overallFidelity}</p><p className={`text-sm ${result.summary.overallFidelity === 'Alta' ? 'text-blue-800' : result.summary.overallFidelity === 'Media' ? 'text-orange-800' : 'text-gray-800'}`}>Fidelidad General</p></div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
