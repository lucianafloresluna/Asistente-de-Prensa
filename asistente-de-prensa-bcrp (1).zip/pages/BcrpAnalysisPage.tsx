import React, { useState, useEffect } from 'react';
import { InputArea } from '../components/InputArea';
import { ResultDisplay } from '../components/ResultDisplay';
import { analyzeContent } from '../services/geminiService';
import { loadGapiScript, showPicker, downloadFileFromId, isGoogleDriveConfigured } from '../services/googlePickerService';
import { AnalysisResult } from '../types';

export const BcrpAnalysisPage: React.FC = () => {
  const [text, setText] = useState<string>('');
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isDriveReady, setIsDriveReady] = useState<boolean>(false);
  const [isImporting, setIsImporting] = useState<boolean>(false);

  useEffect(() => {
    if (isGoogleDriveConfigured()) {
      loadGapiScript()
        .then(() => setIsDriveReady(true))
        .catch(() => setError("No se pudo cargar la API de Google. La selección desde Drive no estará disponible."));
    }
  }, []);

  const handleSubmit = async () => {
    if (!text && !file) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const analysisResult: AnalysisResult = await analyzeContent(text, file);
      setResult(analysisResult);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Ocurrió un error inesperado.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectFromDrive = async () => {
    if (!isDriveReady) return;
    try {
      const driveFile = await showPicker();
      if (driveFile) {
        setFile(driveFile);
        setText(''); // Clear text when a file is selected
      }
    } catch (err) {
       if (err instanceof Error && err.message !== "The user closed the picker.") {
         setError(err.message);
       } else if (!(err instanceof Error)) {
         setError("Ocurrió un error al seleccionar el archivo de Drive.");
       }
    }
  };

  const extractDriveIdFromUrl = (url: string): string | null => {
      const regexes = [
          /drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]{25,})/,
          /drive\.google\.com\/open\?id=([a-zA-Z0-9_-]{25,})/
      ];
      for (const regex of regexes) {
          const match = url.match(regex);
          if (match && match[1]) {
              return match[1];
          }
      }
      return null;
  };

  const handleImportFromUrl = async (url: string) => {
      const fileId = extractDriveIdFromUrl(url);
      if (!fileId) {
          setError("El enlace de Google Drive no parece ser válido.");
          return;
      }

      setIsImporting(true);
      setError(null);
      setResult(null);

      try {
          const driveFile = await downloadFileFromId(fileId);
          setFile(driveFile);
          setText('');
      } catch (err) {
          if (err instanceof Error) {
              setError(`Error al importar desde Drive: ${err.message}`);
          } else {
              setError("Ocurrió un error inesperado al importar desde Drive.");
          }
      } finally {
          setIsImporting(false);
      }
  };


  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start animate-fade-in">
        <InputArea 
        text={text}
        setText={setText}
        file={file}
        setFile={setFile}
        onSubmit={handleSubmit}
        isLoading={isLoading}
        onSelectFromDrive={handleSelectFromDrive}
        isDriveReady={isDriveReady}
        onImportFromUrl={handleImportFromUrl}
        isImporting={isImporting}
        />
        <ResultDisplay 
        result={result}
        isLoading={isLoading}
        error={error}
        />
    </div>
  );
};